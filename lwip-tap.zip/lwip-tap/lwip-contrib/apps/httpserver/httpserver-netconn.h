#ifndef __HTTPSERVER_NETCONN_H__
#define __HTTPSERVER_NETCONN_H__

void http_server_netconn_init();

#endif /* __HTTPSERVER_NETCONN_H__ */
