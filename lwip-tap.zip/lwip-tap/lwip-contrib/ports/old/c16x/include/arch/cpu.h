#ifndef __CPU_H__
#define __CPU_H__

#define BYTE_ORDER LITTLE_ENDIAN

#endif /* __CPU_H__ */
